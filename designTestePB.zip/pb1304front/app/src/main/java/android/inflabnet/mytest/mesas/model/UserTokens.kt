package android.inflabnet.mytest.mesas.model

class UserTokens (var user: String = "",
                  var token: String = "",
                  var ts: String = "")