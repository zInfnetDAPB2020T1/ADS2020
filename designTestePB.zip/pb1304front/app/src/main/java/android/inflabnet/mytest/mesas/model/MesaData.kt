package android.inflabnet.mytest.mesas.model

import java.io.Serializable

class MesaData (var nameMesa: String,
                var proprietarioMesa: String): Serializable