package android.inflabnet.mytest.mesas.model

data class MembrosMesa (
    val nomeMesa: String = "",
    val membro: String = "",
    var id: String =""
)