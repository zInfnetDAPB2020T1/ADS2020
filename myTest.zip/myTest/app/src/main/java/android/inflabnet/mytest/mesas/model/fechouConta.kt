package android.inflabnet.mytest.mesas.model

class fechouConta (val user: String = "",
                   val mesa: String = "",
                   val totConta: Int = 0,
                   val id: String = "")